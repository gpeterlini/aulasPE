#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct aleatorio{
    char x;
    char y;
} aleatorio;

int main(int argc, char **argv){
    FILE * txt;
    aleatorio array[10];
    for(int i=0; i<10; i++){
        array[i].x = i;
        array[i].y = i;
    }
    
    for(int j=0; j<10; j++){
        printf("%c %c\n", array[j].x, array[j].y);
    }
    printf("\n");

    
    txt = fopen("texto.txt", "wb");
    fwrite(array, sizeof(char), strlen(array[0]),txt);
    
    fclose(txt);
    return 0;
}
